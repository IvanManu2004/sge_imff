# -*- coding: utf-8 -*-

from odoo import models, fields, api


class metrica(models.Model):
    _name = 'subscription.metrica'
    _description = 'subscription.subscription'

    fecha = fields.Date()
    suscripciones_activas = fields.Integer()
    ingresos = fields.Float()
    tasa_renovacion = fields.Float(compute='_valor_tasa_renovacion')
    tasa_cancelacion = fields.Float(compute='_valor_tasa_cancelacion')
    nuevas_suscripciones = fields.Integer()
    suscripciones_renovadas = fields.Integer()
    suscripciones_canceladas = fields.Integer()
    clientes_recurrentes = fields.Integer()
    clientes_nuevos = fields.Integer()
    arpu = fields.Float(compute='_valor_arpu')
    tasa_conversion = fields.Float()
    churn_rate = fields.Float()
    lifetime_value = fields.Float()
    cac = fields.Float()
    notas = fields.Text()
    relacion_suscripciones = fields.One2many(comodel_name='subscription.subscription', inverse_name='relacion_metrica')

    @api.depends('suscripciones_renovadas', 'suscripciones_activas')
    def _valor_tasa_renovacion(self):
        for record in self:
            if record.suscripciones_renovadas and record.suscripciones_activas:
                record.tasa_renovacion = (record.suscripciones_renovadas / record.suscripciones_activas) * 100
            else:
                record.tasa_renovacion = 0.0
            
    @api.depends('suscripciones_canceladas', 'suscripciones_activas')
    def _valor_tasa_cancelacion(self):
        for record in self:
            if record.suscripciones_canceladas and record.suscripciones_activas:
                record.tasa_cancelacion = (record.suscripciones_canceladas / record.suscripciones_activas) * 100
            else : 
                record.tasa_cancelacion = 0.0
            
    @api.depends('ingresos', 'suscripciones_activas')
    def _valor_arpu(self):
        for record in self:
            if record.ingresos and record.suscripciones_activas:
                record.arpu = record.ingresos / record.suscripciones_activas
            else:
                record.arpu = 0.0