# -*- coding: utf-8 -*-

from datetime import date, timedelta
from odoo import models, fields, api


class subscription(models.Model):
    _name = 'subscription.subscription'
    _description = 'subscription.subscription'

    name = fields.Char(required=True)
    customer_id = fields.Many2one(
        'res.partner',
        required=True
    )
    subscription_code = fields.Char(required=True)
    start_date = fields.Date(required=True)
    end_date = fields.Date()
    renewal_date = fields.Date()
    status = fields.Selection([
        ('active', 'Active'),
        ('expired', 'Expired'),
        ('pending', 'Pending'),
        ('cancelled', 'Cancelled')
    ])
    is_renewable = fields.Boolean()
    auto_renewal = fields.Boolean()
    price = fields.Float()
    usage_limit = fields.Integer()
    current_usage = fields.Integer()
    use_percent = fields.Float(compute="_value_porcentaje")
    relacion_metrica = fields.Many2one(comodel_name='subscription.metrica', inverse_name='relacion_suscripciones')

    @api.depends('usage_limit', 'current_usage')
    def _value_porcentaje(self):
        for record in self:
            if record.current_usage and record.current_usage > 0 and record.usage_limit and record.usage_limit > 0:
                record.use_percent = float((record.current_usage / record.usage_limit) * 100)
            else:
                record.use_percent = 0.0

    @api.depends('end_date')
    def action_anadir_quince_dias(self):
        for record in self:
            record.end_date = record.end_date + timedelta(days=15)
